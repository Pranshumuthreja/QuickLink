// Function to shorten a URL
async function shortenURL() {
    const url = document.getElementById('urlInput').value;
    const response = await fetch('/url', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ url })
    });
    const result = await response.json();
    if (result.id) {
        document.getElementById('result').innerHTML = `Shortened URL: <a href="/${result.id}" target="_blank">/${result.id}</a>`;
    } else {
        document.getElementById('result').innerHTML = `Error: ${result.error}`;
    }
}

// Function to get analytics for a shortened URL
async function getAnalytics() {
    const shortId = document.getElementById('shortIdInput').value;
    const response = await fetch(`/url/analytics/${shortId}`);
    const result = await response.json();
    if (result.totalClicks !== undefined) {
        document.getElementById('analytics').innerHTML = `Total Clicks: ${result.totalClicks}`;

        // Display chart
        displayChart(result.analytics);
    } else {
        document.getElementById('analytics').innerHTML = `Error: Analytics not found for this short ID.`;
    }
}

// Function to display chart
function displayChart(analytics) {
    const ctx = document.getElementById('analyticsChart').getContext('2d');
    const timestamps = analytics.map(entry => new Date(entry.timestamp).toLocaleString());
    const clickCounts = analytics.map(entry => 1); // Every entry is a click

    // Show the chart
    document.getElementById('analyticsChart').style.display = 'block';

    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: timestamps,
            datasets: [{
                label: 'Clicks',
                data: clickCounts,
                backgroundColor: 'rgba(92, 184, 92, 0.5)',
                borderColor: 'rgba(92, 184, 92, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Number of Clicks'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Timestamps'
                    }
                }
            },
            responsive: true,
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
}
